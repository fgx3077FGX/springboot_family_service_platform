package com.mashibing.mapper;

import com.mashibing.bean.FyRefundSub;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 退款单子单 Mapper 接口
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
public interface FyRefundSubMapper extends BaseMapper<FyRefundSub> {

}
