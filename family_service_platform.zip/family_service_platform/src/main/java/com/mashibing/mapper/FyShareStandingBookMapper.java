package com.mashibing.mapper;

import com.mashibing.bean.FyShareStandingBook;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 公摊费用台账概要 Mapper 接口
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
public interface FyShareStandingBookMapper extends BaseMapper<FyShareStandingBook> {

}
