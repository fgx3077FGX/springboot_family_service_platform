package com.mashibing.mapper;

import com.mashibing.bean.TblMessageCharge;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 短信充值单 Mapper 接口
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
public interface TblMessageChargeMapper extends BaseMapper<TblMessageCharge> {

}
