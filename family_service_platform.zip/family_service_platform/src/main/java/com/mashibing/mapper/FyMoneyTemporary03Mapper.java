package com.mashibing.mapper;

import com.mashibing.bean.FyMoneyTemporary03;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 费用临时表3 Mapper 接口
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
public interface FyMoneyTemporary03Mapper extends BaseMapper<FyMoneyTemporary03> {

}
