package com.mashibing.mapper;

import com.mashibing.bean.FyMoneyTemporary02;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 费用临时表2 Mapper 接口
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
public interface FyMoneyTemporary02Mapper extends BaseMapper<FyMoneyTemporary02> {

}
