package com.mashibing.mapper;

import com.mashibing.bean.TblRoleMenuPrivi;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 角色菜单权限 Mapper 接口
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
public interface TblRoleMenuPriviMapper extends BaseMapper<TblRoleMenuPrivi> {

}
