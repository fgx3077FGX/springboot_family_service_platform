package com.mashibing.mapper;

import com.mashibing.bean.FyInvalidSub;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 作废单子单 Mapper 接口
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
public interface FyInvalidSubMapper extends BaseMapper<FyInvalidSub> {

}
