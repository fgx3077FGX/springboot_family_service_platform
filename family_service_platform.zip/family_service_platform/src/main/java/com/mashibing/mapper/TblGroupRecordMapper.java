package com.mashibing.mapper;

import com.mashibing.bean.TblGroupRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 群组档案 Mapper 接口
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
public interface TblGroupRecordMapper extends BaseMapper<TblGroupRecord> {

}
