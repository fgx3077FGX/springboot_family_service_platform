package com.mashibing.mapper;

import com.mashibing.bean.TblPrintParam;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 打印参数 Mapper 接口
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
public interface TblPrintParamMapper extends BaseMapper<TblPrintParam> {

}
