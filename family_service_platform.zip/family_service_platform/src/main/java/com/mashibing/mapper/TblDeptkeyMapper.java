package com.mashibing.mapper;

import com.mashibing.bean.TblDeptkey;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 部门key Mapper 接口
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
public interface TblDeptkeyMapper extends BaseMapper<TblDeptkey> {

}
