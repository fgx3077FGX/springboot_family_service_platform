package com.mashibing.mapper;

import com.mashibing.bean.FyReceiptSub;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 收款单子单 Mapper 接口
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
public interface FyReceiptSubMapper extends BaseMapper<FyReceiptSub> {

}
