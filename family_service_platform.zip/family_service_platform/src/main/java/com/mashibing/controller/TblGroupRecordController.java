package com.mashibing.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 群组档案 前端控制器
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
@Controller
@RequestMapping("/tblGroupRecord")
public class TblGroupRecordController {

}

