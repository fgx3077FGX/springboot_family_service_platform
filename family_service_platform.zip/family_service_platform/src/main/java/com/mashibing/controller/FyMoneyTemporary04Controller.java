package com.mashibing.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 费用临时表4 前端控制器
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
@Controller
@RequestMapping("/fyMoneyTemporary04")
public class FyMoneyTemporary04Controller {

}

