package com.mashibing.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 个人设置 前端控制器
 * </p>
 *
 * @author lian
 * @since 2023-02-26
 */
@Controller
@RequestMapping("/tblMyset")
public class TblMysetController {

}

